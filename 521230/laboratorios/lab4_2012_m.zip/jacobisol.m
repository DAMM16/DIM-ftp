function [soljac,convergencia,iteraciones] = jacobisol(A,b,x0,tol,maxiter)
% se resuelve sistema Ax = b con metodo de Jacobi
% los primeros dos parametros de entrada son matriz A y parte derecha b
% la solucion se almacena en soljac
% los restantes parametros son:
% x0: aproximacion inicial, tol: tolerancia y 
% maxit: maximo numero de iteraciones. 
% en soljac se guarda la aproximacion a la solucion exacta del sistema a
% resolver
% convergencia indica si se alcanzo la precision deseada en 
% la solucion numerica (1 indica que si se alcanzo, 0 indica que no)
% iteraciones indicara el numero de iteraciones necesarias para obtener la
% precision deseada (si convergencia es 1) o sera igual al numero maximo
% de iteraciones (si convergencia es 0)

[m,n] = size(A);


% necesario para implementar criterio de parada en laminas del curso
x00 = zeros(length(x0),1);
% inicializando numero de iteracion actual
it = 1;
% inicializando variable que chequea si se alcanzo la tolerancia 
% requerida en la solucion aproximada
conv = 0;    
while ~conv && it <= maxiter
    % inicializar vector donde se almacena iterando a calcular en paso
    % actual
    xnew = zeros(n,1);
    % ciclo del metodo de Jacobi
    for j = 1 : n
        suma = 0;
        for k = 1 : j-1
            suma = suma + A(j,k)*x0(k);
        end
        for k = j+1 : n
            suma = suma + A(j,k)*x0(k);
        end
        xnew(j) = (b(j)-suma)/A(j,j);
    end
    % se ha calculado el iterando actual, se comprueba si se alcanzo la
    % tolerancia requerida, para ello debe comprobarse si
    % coef*norm(diferencia entre iterando actual e iterando anterior)
    % es menor o igual que la tolerancia requerida, coef se especifica
    % en las transparencias del curso 
    if it >= 2
        % aproximando norma de matriz de iteracion
        nM = norm(xnew-x0,inf)/norm(x0-x00,inf);
        coef = nM/(1-nM);
        if coef <= 0
            coef = 1;
        end
    else
        coef = 1;
    end
    conv = (coef*norm(xnew-x0,inf) <= tol);
    x00 = x0;
    x0 = xnew;
    % aumentando numero de iteraciones
    it = it + 1;
end
soljac = xnew;
convergencia = conv;
iteraciones = it-1;