function A = create_sparse_trid(n,a,b,c)
% crear matriz tridiagonal de tamanno n de forma sparse
% todos los elementos sobre diagonal principal son
% iguales a a
% los elementos en diagonal encima de diagonal principal
% son iguales a b
% elementos debajo de diagonal principal son iguales a c

% Laboratorio 3, calculo numerico (521230), S2-2012

% Uso del comando diag para crear matrices diagonales
% El primer parametro es el vector que se colocara sobre una de las
% diagonales de la matriz a crear
% el 2do parametro indica cual diagonal debe hacerse igual al vector de
% entrada
% Si se omite el 2do parametro, el vector de entrada es asignado a la
% diagonal principal de la matriz a crear
A = spdiags([c*ones(n,1) a*ones(n,1) b*ones(n,1)],-1:1,n,n);