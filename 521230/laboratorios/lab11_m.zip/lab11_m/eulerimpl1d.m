function [t,y] = eulerimpl1d(f,df,t0,tF,y0,h)
% funcion para resolver la ecuacion diferencial
% y' = f(t,y), t \in [t0,tF], y(t0) = y0
% con el metodo implicito de Euler y tamanno de paso constante = h
% retorna los valores de t en los que se calcula aproximacion a y(t) con el
% metodo de Euler y en el vector y las aproximaciones correspondientes
% f, df: funciones para evaluar f(t,y) y la derivada parcial de f con
% respecto a y en puntos (t,y).

% lab10, pregunta 1, 521230, S2-2011

% n debe ser natural
n = ceil((tF-t0)/h);
% actualizando h
h = (tF-t0)/n;

% puntos donde se calcula aproximacion
t = t0:h:tF;
% inicializando vector donde se almacenaran aproximaciones a y(t)
y = zeros(n+1,1);
% guardando valor inicial en y
y(1) = y0;


for i = 1 : n
    % en cada paso es necesario resolver una ecuacion no lineal
    % hacemos 3 iteraciones del metodo de newton para ello
    y0 = y(i);
    for k = 1 : 3
        derf = feval(df,t(i+1),y0);
        derfnewton = 1 - h*derf;
        f0 = feval(f,t(i+1),y0);
        fnewton = y0 - y(i) - h*f0;
        y0 = y0 - fnewton/derfnewton;
    end
    y(i+1) = y0;
end



