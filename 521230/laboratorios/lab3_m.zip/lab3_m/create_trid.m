function A = create_trid(n,a,b,c)
% crear matriz tridiagonal de tamanno n 
% todos los elementos sobre diagonal principal son
% iguales a a
% los elementos en diagonal encima de diagonal principal
% son iguales a b
% elementos debajo de diagonal principal son iguales a c

% Laboratorio 3, calculo numerico (521230), S2-2011
if ~isnumeric(a) || ~isnumeric(b) || ~isnumeric(c) || ~isnumeric(n)
    error('entrada debe estar compuesta por numeros');
end
% Uso del comando diag para crear matrices diagonales
% El primer parametro es el vector que se colocara sobre una de las
% diagonales de la matriz a crear
% el 2do parametro indica cual diagonal debe hacerse igual al vector de
% entrada
% Si se omite el 2do parametro, el vector de entrada es asignado a la
% diagonal principal de la matriz a crear
A = diag(a*ones(n,1)) + diag(b*ones(n-1,1),1) + diag(c*ones(n-1,1),-1);