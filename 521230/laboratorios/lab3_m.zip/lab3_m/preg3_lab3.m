% pregunta 3, laboratorio 3, calculo numerico (521230), S2-2011

% percatandonos de que A\b es equivalente a descomposicion LU
% con pivoteo parcial y solucion de sistemas triangulares
% Si la matriz del sistema de ecuaciones es estrictamente diagonal
% dominante, no es necesario realizar pivoteo parcial (intercambios de
% filas) para calcular su descomposicion LU

% creando matriz tridiagonal, esta matriz es estrictamente diagonal
% dominante
A = create_trid(10,4,1,1);
% parte derecha del sistema con componentes aleatorias
b = rand(10,1);
% descomposicion LU con pivoteo parcial de A
[L,U,P]=lu(A);
% solucion mediante \
x1 = A\b;
% solucion con ayuda de L y U
% esto es equivalente a resolver los sistemas
% Ly = b y Ux = y pues Ux = y se escribe en matlab como x = U\y
% y si sustituimos en esa expresion para x la expresion para y (= L\b)
% obtenemos exactamente U\(L\b)
x2 = U\(L\b);
disp('matriz tridiagonal y diagonal dominante')
disp('matriz de permutacion deberia ser igual a identidad')
disp('diferencia P-I debe ser matriz nula')
P-eye(10)
disp('diferencia entre soluciones x1=A\b, x2 = U\L\b')
norm(x1-x2)
% residuos
disp('residuo r1=Ax1-b')
r1 = b-A*x1
disp('residuo r2 = Ax2-b')
r2 = b-A*x2

% repitiendo el ejemplo con matrix aleatoria
% si no es estrictamente diagonal dominante, lo mas probable es que sean
% necesarios intercambios de filas al calcular su descomposicion LU con
% pivoteo parcial, es decir, P sera distinta de la matriz identidad
A = rand(10);
while rank(A) ~= 10
    A = rand(10);
end
% parte derecha del sistema a resolver
b = rand(10,1);
% descomposicion LU con pivoteo parcial
[L,U,P] = lu(A);
% solucion mediante \
x1 = A\b;
% resolviendo sistemas triangulares 
x2 = U\(L\(P*b));
disp('matriz aleatoria')
disp('P no es identidad')
disp('diferencia P-I no es matriz nula')
P - eye(10);
disp('PA - LU debe ser matriz nula')
P*A-L*U
disp('diferencia entre soluciones x1=A\b, x2 = U\L\(Pb)')
norm(x1-x2)
% residuos
disp('residuo r1=Ax1-b')
r1 = b-A*x1
disp('residuo r2 = Ax2-b')
r2 = b-A*x2

