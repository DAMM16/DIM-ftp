% pregunta 2, laboratorio 3 calculo numerico (521230), S2-2011

% comparando A\B (descomposici�n LU de A se calcula 1 sola vez y se usa
% para resolver todos los sistemas) con ciclo para encontrar A\B(:,i), en
% cuyo caso es necesario calcular una nueva descomposici�n LU cada vez
A = rand(50);
% mientras A sea singular, generar nueva A
while rank(A) ~= 50
    A = rand(50);
end
% matriz con 100 partes derecha distintas
B = rand(50,100);
% con tic,toc y cputime no se obtiene la misma estimacion del tiempo
% necesario para calcular X e Y. matlab recomienda el uso de tic,toc
tic
% t0 = cputime;
X = A\B;
% t1 = cputime-t0
toc

% en Y se almacenaran las soluciones a los 100 sistemas de ecuaciones
Y = zeros(50,100);
% t0 = cputime;
tic
for i = 1:100
    Y(:,i) = A\B(:,i);
end
% t1 = cputime-t0
toc

% X e Y deben ser iguales
norm(X-Y,inf)
