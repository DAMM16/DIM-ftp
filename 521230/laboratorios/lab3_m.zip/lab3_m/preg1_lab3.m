% laboratorio 3 de calculo numerico (521230), S2-2011

% Pregunta 1, llamando a calcular_tiempos y graficando
tiempos = comparar_tiempos(10:10:100);
% tiempo de eliminaci�n gaussiana
plot(tiempos(:,1),'o')
hold on
% tiempo mediante calculo inversa
plot(tiempos(:,2),'x')
% tiempo mediantee Cramer
plot(tiempos(:,3),'*')
legend('Gauss','Inversa','Cramer')
% generar un 2do grafico con las 2 primeras columnas de tiempos
% para ver mejor la diferencia entre el tiempo necesario para
% calcular x con Gauss y mediante inv(A)*b
% solo Gauss e inversa
figure(2)
% tiempo de eliminacion gaussiana
plot(tiempos(:,1),'o')
hold on
% tiempo mediante calculo inversa
plot(tiempos(:,2),'x')
legend('Gauss','Inversa')