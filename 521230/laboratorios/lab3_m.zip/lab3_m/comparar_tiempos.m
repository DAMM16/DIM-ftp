function [tiempos] = comparar_tiempos(nvec)
% funcion para comparar tiempos necesarios
% para resolver Ax=b mediante eliminacion gaussiana,
% calculo de inversa y metodo de Cramer
% Laboratorio 3, calculo numerico (521230), S2-2011

nvec = floor(nvec(:));
if ~isnumeric(nvec) || any(nvec <= 0) || any(isinf(nvec))
    error('entrada erronea')
end
% creando matriz donde se almacenaran los tiempos que demora cada metodo de
% solucion
tiempos = zeros(length(nvec),3);
% ciclo que recorre los valores en nvec
for i = 1:length(nvec)
    n = nvec(i);
    % creando matriz del sistema a resolver
    A=-diag(ones(n-1,1),1)+diag(2*ones(n,1))-diag(ones(n-1,1),-1);
    % esta matriz tambien pudo crearse con la funcion create_trid escrita
    % en este laboratorio, el llamado seria
    % A = create_trid(n,2,-1,-1)
    
    % creando vector parte derecha del sistema que se va a resolver
    b = ones(n,1);
    
    % resolviendo por eliminacion gaussiana
    tic
    x = A\b;
    tiempos(i,1) = toc;
    % resolviendo mediante calculo inversa
    tic
    x = inv(A)*b;
    tiempos(i,2) = toc;
    % resolviendo mediante Cramer
    tic
    dA = det(A);
    for k = 1:length(b)
        newA = [A(:,1:k-1) b A(:,k+1:length(b))];
        x(k) = det(newA)/dA;
    end
    tiempos(i,3) = toc;    
end
