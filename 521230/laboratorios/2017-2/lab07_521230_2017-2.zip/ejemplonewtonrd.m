% preg 2, lab 8, 521230, S1-2015

% raices de F son los pares (x,x^2) con x raiz del polinomio 
% x^4 + x^3 + x^2 - 1
x = roots([1 1 1 0 -1])
y = x.^2

x0 = [1/4;1/4]; % converge a (0.6823,(0.6823)^2) en 6 iteraciones

[sol,it] = newtonrd('Fxy','dFxy',x0,1e-10,30);
if it > -1
    display('numero de iteraciones para obtener precision deseada')
    it
    display('aproximacion a cero de f')
    sol
else
    display('metodo no obtuvo precision deseada en maximo de iteraciones dado')
end