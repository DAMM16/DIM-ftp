% rutero para resolver preg3, lab7, 521230, S2-2011
load espiral
% graficar puntos de espiral
plot(x,y,'o');
hold on
% spline cubico natural que interpola (i,x(i))
csx = csape(1:17,x,[2 2]);
% spline cubico natural que interpola (i,y(i))
csy = csape(1:17,y,[2 2]);
% graficar (csx,cxy)
x = linspace(1,17);
xval = fnval(csx,x);
yval = fnval(csy,x);
% graficar curva parametrica de espiral
plot(xval,yval,'r');
legend('puntos espiral','spline cub. natural');
