% rutero para responder a preg2, lab 7, 521230, S2-2011
% puntos donde el polinomio interpola a la funcion, son 11 de ellos
load pieza
plot(x1,y1);
hold on
plot(x2,y2,'r');
plot(x3,y3,'k');
% los 3 contornos no forman una funcion, puedo aproximar ([x1 x2],[y1 y2])
% con un polinomio y (x3, y3) con otro.
% si se va a interpolar la funcion por un spline cubico, no es buena idea
% aproximar todo el tramo ([x1 x2],[y1 y2]) por un spline pues el spline es
% una funcion con 2da derivada continua, mientras que la funcion que
% describe el contorno de la pieza una discontinuidad en la primera
% derivada en el punto 0 (ultimo punto en x1 y primero en x2). Observe la
% diferencia entre el spline y la funcion si usamos un unico spline para
% aproximar la funcion dada por ([x1 x2],[y1 y2])
x1 = x1(:);
y1 = y1(:);
x2 = x2(:);
y2 = y2(:);
x3 = x3(:);
y3 = y3(:);
cs12 = csape([x1;x2],[y1;y2],[2 2]);
cs3 = csape(x3,y3,[2 2]);
figure(2);
plot(x1,y1);
hold on
plot(x2,y2);
plot(x3,y3);
fnplt(cs12,1,'r',[min([x1;x2]),max([x1;x2])])
fnplt(cs3,1,'k',[min(x3),max(x3)]);
% Conviene aproximar (x1,y1) por un spline cubico, (x2, y2) por otro 
% y (x3, y3) por otro.
% si hacemos esto, obtenemos
figure(3);
plot(x1,y1);
hold on
plot(x2,y2);
plot(x3,y3);
cs1 = csape(x1,y1,[2 2]);
cs2 = csape(x2,y2,[2 2]);
cs3 = csape(x3,y3,[2 2]);
fnplt(cs1,1,'r',[min(x1) max(x1)]);
fnplt(cs2,1,'k',[min(x2),max(x2)]);
fnplt(cs3,1,'g',[min(x3),max(x3)]);