function val = Fxy(x)
% funcion en preg 4, lab 7, 521230, S2, 2012

val = zeros(2,1);
val(1) = x(1)^2 + x(1)*x(2) + x(2)^2 - 1;
val(2) = x(2) - x(1)^2;