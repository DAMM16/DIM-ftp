% rutero para resolver preg 2, lab 6 521230, S2-2011
% matriz para ajuste de datos
A = [2.5 2.3 5.6 1;
    1.5 12.3 0.33 1;
    8.9 -1.88 9.99 1;
    5.77 2.2 5.66 1;
    8.73 4.51 1.19 1;
    3.14 6.28 8.87 1;
    0.77 1.45 11.1 1];
% viendo puntos donde se midio velicidad de cuerpo extranno
plot3(A(:,1),A(:,2),A(:,3),'o','LineWidth',3)
hold on
% punto en rojo es el satelite
plot3(0.56,1.23,1.53,'ro','LineWidth',3)
% velocidades de cuerpo extranno
b = [54.6 69.98 79.24 64.27 57.88 96.04 78.16]';
% ajustando datos, matlab resuelve el sistema automaticamente con
% descomposicion QR de A
vcoef = A\b;

% evaluar v para averiguar velocidad de cuerpo extranno al pasar por punto
% (0.56, 1.23, 1.53)
disp('velocidad al chocar con satelite')
velocidad = vcoef(1)*0.56  + vcoef(2)*(1.23) + vcoef(3)*1.53 + vcoef(4)


