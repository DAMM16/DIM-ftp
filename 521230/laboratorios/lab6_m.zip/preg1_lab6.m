% rutero para responder a pregunta 1 de laboratorio 6, 521230, S2, 2011
A = [0.4 0 0 0.2;0 0.4 0.3 0.2;0 0.3 0.4 0.2;0.6 0.3 0.3 0.4];
% para determinar si A es invertible
disp('det(A)')
det(A)
disp('rango de A')
rank(A)
% numero inicial de salmones si despues de 1 hora hay 12,25,26 y 37 mil 
disp('salmones 1 hora antes si hay 12,25,26,37 mil')
A\[12;25;26;37]
% si originalmente hay 25 mil en cada celda
% despues de 1 hora habra
disp('salmones 1 hora despues con 25 mil en cada celda al inicio')
A*[25;25;25;25]
% despues de 3 horas
disp('salmones 3 horas despues con 25 mil en cada celda al inicio')
A*(A*(A*[25;25;25;25]))
% funcion salmones.m es respuesta a 1.4
salmones([25;25;25;25]);
% por prueba y error, 21 000 en cada celda
close all
salmones([21;21;21;21]);

