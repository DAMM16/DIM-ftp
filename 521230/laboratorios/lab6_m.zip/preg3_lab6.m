% rutero para preg3, lab6, 521230, S2-2011
clear all
load elsurdata
whos
% crear matriz de sistema de ecuaciones para calcular rangos
A = creatematrix_pagerank(Gelsur);
% ver estructura de A, A es rala y no es simetrica
% si se calcula descomposicion LU de A, las matrices L y U tendran
% muchas mas entradas distintas de cero que A. Dado que esta matriz A
% puede ser bastante grande, pero con muchos elementos iguales a cero, no
% es conveniente usar un metodo directo para resolver el sistema
spy(A)
title('Estructura matriz sistema para calcular pagerank')
nnz(A)
% jacobi, con tol=1e-6 demora bastante, se puede tomar mayor
[xj,coj,itj] = jacobisol(A,ones(size(A,1),1),zeros(size(A,1),1),1e-6,100);
disp('jacobi')
disp('alcanza tol=1e-6 en ')
itj
disp('iteraciones')
figure(2)
mostrarrangos(xj,Gelsur,Uelsur);
title('solucion por metodo de Jacobi')
% gauss-seidel
[xgs,cogs,itgs] = gaussseidelsol(A,ones(size(A,1),1),zeros(size(A,1),1),1e-6,100);
disp('Gauss-Seidel')
disp('alcanza tol=1e-6 en ')
itgs
disp('iteraciones')
figure(3)
mostrarrangos(xgs,Gelsur,Uelsur)
% A no parece ser simetrica, no es posible usar gradiente conjugado ni maximodescenso, pero recordemos
% como se llama al gradiente conjugado y al gradiente conjugado precondicionado.
% gradiente conjugado
[xgc,fgc] = pcg(A,ones(size(A,1),1))
disp('flag gc, si es distinto de cero, no se pudo calcular aproximacion')
fgc
% gradiente conjugado precondicionado, buscando precondicionador con cholinc
P = cholinc(A,1e-2);
% llamado a pcg con valor para P (gradiente conjugado precondicionado)
[xgcp,fgcp] = pcg(A,ones(size(A,1),1),1e-6,100,P);
disp('flag gcp, si es distinto de cero, no se pudo calcular aproximacion')
fgcp
