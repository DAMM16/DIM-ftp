function val = func1_lab10(t,y)
val = -y;