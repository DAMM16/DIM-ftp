function val = dfunc1_lab10(t,y)
val = -eye(length(y));