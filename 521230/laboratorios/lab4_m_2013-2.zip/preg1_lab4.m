% pregunta 1, laboratorio 4, 521230, S2-2013

% numero de veces que se multiplicara una matriz de orden N por si misma
reps = 8;

% ordenes de matrices que se generaran
N = [100 200 400 800];

counterAfull = zeros(length(N),1);
counterAsparse = zeros(length(N),1);								
% multiplicar A por si misma, como full y como sparse, 
% comparar tiempos de ejecucion

% Se crean matrices de distintos ordenes, la version full se guarda en A,
% la version sparse en B
% cada matriz se multiplica por si misma 
for j = 1:length(N)			
    counterAnfull = zeros(reps,1);
    counterAnsparse = zeros(reps,1);
    
    % por cada valor de n (orden de matriz), se generan reps matrices
    % aleatorias y se multiplican por si mismas, almacenadas en forma full
    % y en forma sparse. 
    for i = 1: reps
        v = rand(4,1);
        A = matriz_preg1_lab4(N(j),v(1),v(2),v(3),v(4));
        B = matriz_preg1_lab4_sparse(N(j),v(1),v(2),v(3),v(4));
        
        % tiempo en version full de A
        tic
        B1 = A*A;
        counterAnfull(i)=toc;
        
        % tiempo en version sparse de A
        tic
        B2 = B*B;
        counterAnsparse(i)=toc;
    end
    counterAfull(j) = sum(counterAnfull)/reps;
    counterAsparse(j) = sum(counterAnsparse)/reps;
end
% grafico en escala logaritmo
loglog(N,counterAfull,'o-')
hold on
loglog(N,counterAsparse,'*-')
legend('A full','A sparse');
xlabel('n');
ylabel('tiempo transcurrido para calcular A^2');
title('trabajo con matrices sparse, grafico en escala logaritmica')
set(gca,'xtick',[100 200 300 400 500 600 700 800])   
 
