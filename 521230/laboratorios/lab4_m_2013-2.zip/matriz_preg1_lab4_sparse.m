function A = matriz_preg1_lab4_sparse(n,a,b,c,d)
% crear matriz en preg1, lab 4 directamente como matriz sparse, es decir,
% usando los comandos matlab para crear matrices de este tipo

% Laboratorio 4, S2-2013

% vector cuyas todas sus componentes son iguales a 1
e = ones(n,1);
% matriz con n filas y 5 columnas, de las columnas de B se extraen las
% diagonales de A que se especifican en spdiags. De la 1era se extrae la
% diagonal -1, de la 2da la diagonal 0 y de la 3ra la diagonal 1
B = [c*e a*e b*e];
A = spdiags(B,-1:1,n,n);
% annadiendo con ayuda de sparse los elementos en las posiciones (1,n-2),
% (2,n-1), (3,n), (n-2,1), (n-1,2), (n,3)
A = A + sparse([1 2 3 n-2 n-1 n],[n-2 n-1 n 1 2 3],d,n,n);