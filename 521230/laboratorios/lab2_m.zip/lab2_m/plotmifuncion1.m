% rutero para graficar la funcion almacenada en mifuncion1.m

% Laboratorio 2, Calculo numerico (521230), S2-2011

% graficando f en mifuncion1 entre -pi y pi
% crear vector con valores entre -pi y pi
x = -pi:.01:pi;
% evaluar la funcion
valx = mifuncion1(x);
% graficar
plot(x,valx);