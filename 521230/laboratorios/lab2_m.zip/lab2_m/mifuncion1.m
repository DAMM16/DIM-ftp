function val = mifuncion1(x)
% función para evaluar f(x) = (1-cos(x))/x^2 en x 
% entrada: número real o vector con componentes reales
% salida: valor o valores de la función en la entrada

% Laboratorio 2, Calculo numerico (521230), S2-2011

% cambiando x a vector columna
x = x(:);
if ~isnumeric(x) || ~isreal(x) || any(~isfinite(x))
    error('entrada debe ser vector de números reales')
end
% creando arreglo de zeros con mismo número de elementos que x
val = zeros(length(x),1);
% escogiendo de x los elementos distintos de cero
xdiff0 = x(x~=0);
% evaluando función en x distinto de cero
val(x ~= 0) = (1-cos(xdiff0))./xdiff0.^2;
% en cero la función es 1/2
val(x == 0) = .5;