% rutero para preg 3 del lab 5, S2-2011
data = load('CO2.mat');
% concentraciones
c = data.c;
% longitud de c es el numero de datos
m = length(c);
% esos datos se ajustan por funcion A + Bexp(a*t) + C*cos(2pit/12) +
% D*sin(2pit/12), t varia entre 1 y 48, t=1 representa enero 1998, t=48 a
% diciembre de 2001
t = 1:48;
t=t';
a = 0.0037;
A = zeros(m,4);
A(:,1) = ones(m,1);
A(:,2) = exp(a*t);
A(:,3) = cos(2*pi*t/12);
A(:,4) = sin(2*pi*t/12);
% matlab aplica descomposicion QR
coeffunc = A\c;
plot(t,c,'*');
hold on
plot(t,coeffunc(1)+coeffunc(2)*exp(a*t) + coeffunc(3)*cos(2*pi*t/12)+coeffunc(4)*sin(2*pi*t/12));
% evaluando en t=61,62,63 obtenemos concentracion de CO2 en los meses de
% enero a marzo de 2003
disp('enero, febrero, marzo 2003')
tnew = [61,62,63];
coeffunc(1)+coeffunc(2)*exp(a*tnew) + coeffunc(3)*cos(2*pi*tnew/12)+coeffunc(4)*sin(2*pi*tnew/12)