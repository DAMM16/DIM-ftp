function [A, t] = matriz_ej2_lab5(m,n)
% funcion para construir matriz de ejercicio 2, laboratorio 5

% contruimos el vector t con los m+1 puntos equiespaciados en [0,1]
t = linspace(0,1,m+1); % t es un vector fila
% haciendo de t un vector columna
t=t';
% crear A
A = zeros(m+1,n+1);
% completando columnas de A
for i = 1:n+1
    A(:,i) = t.^(n+1-i);
end
