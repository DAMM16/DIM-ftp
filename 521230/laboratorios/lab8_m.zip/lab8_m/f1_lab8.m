function val = f1_lab8(x)
% funcion para evaluar f(x) = sqrt(1-sin(x)), si x es un vector, el valor
% retornado tambien es un vector

val = (1-sin(x)).^(1/2);