function val = sumtrapecios(f,a,b,h)
% regla compuesta del trapecio para calcular la integral de f de a a b 
% tamanno de paso h.

% se calcula numero de subintervalos en que se divide el intervalo de 
% integracion, se hace ceil de (b-a)/h para que el valor de n sea un numero
% natural
n = ceil((b-a)/h);
% i toma n+1 valores desde a hasta b
points = linspace(a,b,n+1);

val1 = feval(f,points(1))+feval(f,points(end));
val2 = sum(feval(f,points(2:end-1)));
val = ((b-a)/n)*(val1/2 + val2);