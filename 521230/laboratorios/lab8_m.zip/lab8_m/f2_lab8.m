function val = f2_lab8(x)
% funcion para evaluar f(x) = exp(x)*sin(x), si x es un vector, el valor
% retornado tambien es un vector

val = exp(x).*sin(pi*x);