function B = createBfull(n)
% B full
B = [2*eye(n) -eye(n);-eye(n) 2*eye(n)];
