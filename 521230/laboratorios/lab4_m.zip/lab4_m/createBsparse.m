function B = createBsparse(n)
% B sparse
B = [2*speye(n) -speye(n);-speye(n) 2*speye(n)];