% rutero preg2_lab4, 521230, S2-2011
% 2.1
B = createBfull(1000);
disp('numero de zeros en B')
nnz(B)
A = sparse(B);
whos

% 2.2
% parte derecha aleatoria
b = rand(2000,1);
% resolver sistema con matriz full
tic
x = B\b;
tfull = toc
% resolver sistema con matriz sparse
tic
y = A\b;
tsparse = toc

% 2.3
% matriz de iteracion de Jacobi
D = diag(diag(A));
E = -(tril(A) - D);
F = -(triu(A) - D);
J = inv(D)*(E+F);

% 2.4
% viendo que D, E, F, J, al haber sido creadas a partir de una matriz
% almacenada como sparse, tambien son almacenadas como sparse
whos
% espiando matrices
figure()
spy(A)
title('A')
figure()
spy(D)
title('D')
figure()
spy(E)
title('E')
figure()
spy(F)
title('F')
figure()
spy(J)
title('J')

% 2.5 es createBsparse.m