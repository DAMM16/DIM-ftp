function [eb,exh, ext] = testingcond(n)
% funcion para chequear consecuencias de un numero de condicion muy grande
disp('numeros de condicion')
disp('matriz de Hilbert')
cond(hilb(n))
disp('matriz tridiagonal')
cond(create_trid(n,4,1,1))
% creando vector parte derecha de los sistemas a resolver
b = ones(n,1);
% perturbando vector parte derecha
tb = b + (2*rand(n,1)-1)*1e-6;
% solucion exacta a sistema Hx = b
xh = invhilb(n)*b;
% solucion exacta a sistema Hy = b+tb
txh = invhilb(n)*tb;
% error relativo en parte derecha
eb = norm(b-tb)/norm(b);
% error relativo en solucion a sistema con matriz de Hilbert
exh = norm(xh-txh)/norm(xh);
% resolviendo sistemas con matriz tridiagonal
xt = invtrid(n,2,1,1)*b;
txt = invtrid(n,2,1,1)*tb;
% error relativo en solucion a sistema con matriz tridiagonal
ext = norm(xt-txt)/norm(xt);